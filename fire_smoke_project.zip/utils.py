"""
utils.py - helper utilities (placeholder)
"""
def sigmoid(x):
    return 1 / (1 + (2.718281828459045)**(-x))