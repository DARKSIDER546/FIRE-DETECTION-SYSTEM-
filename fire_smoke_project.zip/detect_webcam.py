"""
detect_webcam.py
Real-time webcam detection. Requires a trained model.
Usage: python detect_webcam.py
Press 'q' to quit.
"""
import cv2
import numpy as np
from tensorflow.keras.models import load_model

MODEL_PATH = "models/fire_smoke_cnn.h5"

def main():
    if not os.path.exists(MODEL_PATH):
        print("Model not found. Train model first: python train.py")
        return
    model = load_model(MODEL_PATH)
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Cannot open webcam")
        return
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        img = cv2.resize(frame, (128,128))
        arr = img.astype('float32')/255.0
        arr = np.expand_dims(arr, axis=0)
        pred = model.predict(arr)[0][0]
        label = "FIRE" if pred>=0.5 else "SMOKE"
        cv2.putText(frame, f"{label}: {pred:.2f}", (10,30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)
        cv2.imshow("Live Detection - press q to quit", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()

if __name__=="__main__":
    main()